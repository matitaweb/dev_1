$(function() {
	
	// begin ie6 js
	
});