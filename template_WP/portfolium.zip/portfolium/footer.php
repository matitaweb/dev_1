            </div>
        </div>
        <div class="footer clear">
            <div class="footer_inn">
                <div class="left">
                    <p>&copy; 2010 <a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a></p>
                    <p>Powered by <a href="http://wordpress.org">Wordpress</a></p>
                </div>
                <div class="right">
                    <p>Designed by <a href="http://wpshower.com" class="wpshower_logo">Wpshower</a></p>
                </div>
            </div>
        </div>
        <!-- Page generated: <?php timer_stop(1); ?> s, <?php echo get_num_queries(); ?> queries -->
	</body>
</html>
