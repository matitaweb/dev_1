<?php
/**
 * @version   1.0 February 17, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
// no direct access
?>

<?php global $post, $posts, $query_string, $wp_query; ?>

	<div class="blog">
		
			
			<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
			
			if (is_category()) {
				$post_count = $gantry->get('category-count');
				$page_title = $gantry->get('category-page-title');
				$title = $gantry->get('category-title');
				$title_link = $gantry->get('category-link-title');
				$author = $gantry->get('category-meta-author');
				$date = $gantry->get('category-meta-date');
				$comments = $gantry->get('category-meta-comments');
				$comments_link = $gantry->get('category-meta-link-comments');
				$modified = $gantry->get('category-meta-modified');
				$content = $gantry->get('category-content');
				$readmore = $gantry->get('category-readmore');
				$custom_page_title = $gantry->get('category-custom-page-title');
			}
			
			if (is_day() || is_month() || is_year() || is_author()) {
				$post_count = $gantry->get('archive-count');
				$page_title = $gantry->get('archive-page-title');
				$title = $gantry->get('archive-title');
				$title_link = $gantry->get('archive-link-title');
				$author = $gantry->get('archive-meta-author');
				$date = $gantry->get('archive-meta-date');
				$comments = $gantry->get('archive-meta-comments');
				$comments_link = $gantry->get('archive-meta-link-comments');
				$modified = $gantry->get('archive-meta-modified');
				$content = $gantry->get('archive-content');
				$readmore = $gantry->get('archive-readmore');
				$custom_page_title = $gantry->get('archive-custom-page-title');
			}
			
			if (is_tag()) {
				$post_count = $gantry->get('tags-count');
				$page_title = $gantry->get('tags-page-title');
				$title = $gantry->get('tags-title');
				$title_link = $gantry->get('tags-link-title');
				$author = $gantry->get('tags-meta-author');
				$date = $gantry->get('tags-meta-date');
				$comments = $gantry->get('tags-meta-comments');
				$comments_link = $gantry->get('tags-meta-link-comments');
				$modified = $gantry->get('tags-meta-modified');
				$content = $gantry->get('tags-content');
				$custom_page_title = $gantry->get('tags-custom-page-title');
			}
			
            $query = $wp_query->query;
            if (!is_array($query)) parse_str($query, $query); 
			query_posts(array_merge($query, array('posts_per_page' => $post_count, 'paged' => $paged))); ?>
	
			<?php if(have_posts()) : ?>
			
			<?php if($custom_page_title != '') : ?>
			
				<h1 class="rt-pagetitle"><?php echo $custom_page_title; ?></h1>
			
			<?php else : ?>
		    																										
				<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
				<?php /* If this is a category archive */ if (is_category()) { ?>
					<h1 class="rt-pagetitle"><?php _re('Category:'); ?> <?php single_cat_title(); ?></h1>
				<?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
					<h1 class="rt-pagetitle"><?php _re('Posts Tagged'); ?> &#8216;<?php single_tag_title(); ?>&#8217;</h1>
				<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
					<h1 class="rt-pagetitle"><?php _re('Archive for'); ?> <?php the_time('F jS, Y'); ?></h1>
						<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
					<h1 class="rt-pagetitle"><?php _re('Archive for'); ?> <?php the_time('F, Y'); ?></h1>
				<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
					<h1 class="rt-pagetitle"><?php _re('Archive for'); ?> <?php the_time('Y'); ?></h1>
				<?php /* If this is an author archive */ } elseif (is_author()) { ?>
					<h1 class="rt-pagetitle"><?php _re('Author Archive'); ?></h1>
				<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
					<h1 class="rt-pagetitle"><?php _re('Blog Archives'); ?></h1>
				<?php } ?>
			
			<?php endif; ?>
															
			<?php while (have_posts()) : the_post(); ?>
		
			<!-- Begin Post -->
			
			<div class="leading">
					<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
						<?php if($title) : ?>
		
						<!-- Begin Title -->
					
						<div class="rt-headline">
							
							<?php if($title_link) : ?>
							
							<h1 class="title">
								<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</h1>
							<div class="articledivider"></div>
							
							<?php else : ?>
								
							<h1 class="title">
								<?php the_title(); ?>
							</h1>
							<div class="articledivider"></div>
							
							<?php endif; ?>
								
						</div>
						<div class="clear"></div>
							
						<!-- End Title -->
							
						<?php endif; ?>
						
						<?php if($comments || $date || $modified || $author) : ?>
								
							<!-- Begin Meta -->
	
                                     <p class="articleinfo">
                                     	
                                     	<?php if($date) : ?>
                                     	
                                     	<!-- Begin Date & Time -->
                                     	
                                     	<span class="modifydate"><!--<?php _re('Posted on'); ?> --><span><?php the_time('l, d F, Y H:i'); ?></span></span>
                                     	
                                     	<!-- End Date & Time -->
                                        
					<?php endif; ?>    
					     
                                        <?php if($modified) : ?>
					
					<!-- Begin Modified Date -->
                                     
                                     	<span class="modifydate"><?php _re('Last Updated on'); ?> <?php the_modified_date('l, d F, Y H:i', '<span>', '</span>'); ?></span>
                                     	
                                     	<!-- End Modified Date -->
                                     	
                                     	<?php endif; ?>
                                     		
                                     	<?php if($author) : ?>
                                     
                                     	<!-- Begin Author -->
                                     
                                     	<span class="createdby"><?php _re('Written by'); ?> <span><?php the_author(); ?></span></span>
                                     	
                                     	<!-- End Author -->
                                     	
                                     	<?php endif; ?>
                                     	
                                     </p>
                                     
                                     <!-- End Meta -->
						
						<?php endif; ?>
						
						<div class="articlebox">
							<p class="iteminfo"></p>
							<?php if(function_exists('the_post_thumbnail') && has_post_thumbnail()) : the_post_thumbnail('gantryThumb', array('class' => $gantry->get('thumb-position'))); endif; ?>
								<!-- Begin Post Content -->		
							
								<?php if($gantry->get('blog-content') == 'content') : ?>
								
								<?php the_content(false); ?>
													
								<?php else : ?>
													
								<?php the_excerpt(); ?>
														
								<?php endif; ?>
								<div class="clear"></div>
								<?php if(preg_match('/<!--more(.*?)?-->/', $post->post_content)) : ?>
								
								<div class="readon">									
									<a href="<?php the_permalink(); ?>"><span><?php echo $gantry->get('archive-readmore'); ?></span></a>
								</div>
								
								<?php endif; ?>

								<!-- End Post Content -->
														
							<!-- End Post Content -->
							
							<?php if($gantry->get('blog-meta-comments')) : ?>
									
									<!-- Begin Comments -->
									
									<?php if($gantry->get('blog-meta-link-comments')) : ?>
									<div class="readon">
										<a href="<?php the_permalink(); ?>#comments">
											<span><?php comments_number(_r('0 Comments'), _r('1 Comment'), _r('% Comments')); ?></span>
										</a>
									</div>
	
									<?php else : ?>
				
									<div class="readon">
										<span><?php comments_number(_r('0 Comments'), _r('1 Comment'), _r('% Comments')); ?></span>
									</div>
									
									<?php endif; ?>
									
									<!-- End Comments -->
								
								<?php endif; ?>
						
						</div>			
					</div>
					<div class="clear"></div>
			</div>
			
			<!-- End Post -->
			
			<?php endwhile;?>
			
			<!-- Begin Navigation -->
											
			<?php global $wp_query; $total_pages = $wp_query->max_num_pages; if($total_pages > 1) : ?>
					
			<div class="rt-pagination nav">
				<div class="alignleft">
					<?php next_posts_link('&laquo; '._r('Older Entries')); ?>
				</div>
				<div class="alignright">
					<?php previous_posts_link(_r('Newer Entries').' &raquo;') ?>
				</div>
				<div class="clear"></div>
			</div><br />
						
			<?php endif; ?>
	
			<!-- End Navigation -->
			
			<?php else : ?>
																																	
			<h1 class="rt-pagetitle">
				<?php _re("Sorry, but there aren't any posts matching your query."); ?>
			</h1>
															
			<?php endif; ?>
															
			<?php wp_reset_query(); ?>
	
		
	</div>