<?php
/**
 * @version   1.0 February 17, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

// no direct access
?>

<?php global $post, $posts, $query_string; ?>
	<div class="blog">
		
				<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
				
				if($gantry->get('blog-query') != '') : query_posts("'paged=".$paged.'&'.$gantry->get('blog-query')."'");
				
				else: query_posts('paged='.$paged.'&orderby='.$gantry->get('blog-order').'&cat='.$gantry->get('blog-cat').'&post_type='.$gantry->get('blog-type'));
				
				endif; 
				
				?>
		
				<?php while (have_posts()) : the_post(); ?>
			
				<!-- Begin Post -->
					<div class="leading">

				<?php if ($gantry->get('blog-page-title') != '') : ?>
			
			<div class="sectiontitle">
				<?php echo $gantry->get('blog-page-title'); ?>
			</div>
			
			<?php endif; ?>
						
						<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
							
							<?php if($gantry->get('blog-title')) : ?>
			
							<!-- Begin Title -->
								
								<?php if ( count( get_the_category() ) ) : ?>
								<h1 class="title">
								<span><?php print(get_the_category_list( ', ' ) ); ?></span>
								</h1>
								<div class="articledivider"></div>
								<?php endif; ?>
								
								<?php if($gantry->get('blog-link-title')) : ?>
								
								<h2 class="contentheading">
									<span><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></span>
								</h2>
									
								<?php else : ?>	
								<h2 class="contentheading">
									<?php the_title(); ?>
								</h2>
								
									
								<?php endif; ?>
								
							<!-- End Title -->
							
								<?php if($gantry->get('blog-meta-date')) : ?>
								
								<!-- Begin Date & Time -->
			
								<div class="contentdate"><span class="createdate"><!--<?php _re('Posted on'); ?> --><span><?php the_time('d.m.y'); ?></span></span></div>
								
								<!-- End Date & Time -->
								
								<?php endif; ?>
							
								
							<?php endif; ?>
							
							<?php if($gantry->get('blog-meta-comments') || $gantry->get('blog-meta-date') || $gantry->get('blog-meta-modified') || $gantry->get('blog-meta-author')) : ?>
								
							<!-- Begin Meta -->
							
							<p class="articleinfo">
								
								<?php if($gantry->get('blog-meta-modified')) : ?>
								
								<!-- Begin Modified Date -->
			
								<span class="modifydate"><?php _re('Last Updated on'); ?> <?php the_modified_date('l, d F, Y H:i', '<span>', '</span>'); ?></span>
								
								<!-- End Modified Date -->
								
								<?php endif; ?>
									
								<?php if($gantry->get('blog-meta-author')) : ?>
							
								<!-- Begin Author -->
							
								<span class="createdby"><?php _re('Written by'); ?> <span><?php the_author(); ?></span></span>
								
								<!-- End Author -->
								
								<?php endif; ?>
								
							</p>
							
							<!-- End Meta -->
							
							<?php endif; ?>
							
							<div class="articlebox">
							<p class="iteminfo"></p>
								<!-- Begin Post Content -->		
							<?php if(function_exists('the_post_thumbnail') && has_post_thumbnail()) : the_post_thumbnail('gantryThumb', array('class' => $gantry->get('thumb-position'))); endif; ?>
								<?php if($gantry->get('blog-content') == 'content') : ?>
								
								<?php the_content(false); ?>
													
								<?php else : ?>
													
								<?php the_excerpt(); ?>
														
								<?php endif; ?>
								
								<?php if(preg_match('/<!--more(.*?)?-->/', $post->post_content)) : ?>
								<div class="readon">									
									<a href="<?php the_permalink(); ?>"><span><?php echo $gantry->get('blog-readmore'); ?></span></a>
								</div>
								
								<?php endif; ?>

								<!-- End Post Content -->
								
								<?php if($gantry->get('blog-meta-comments')) : ?>
									
									<!-- Begin Comments -->
									
									<?php if($gantry->get('blog-meta-link-comments')) : ?>
									<div class="readon">
										<a href="<?php the_permalink(); ?>#comments">
											<span><?php comments_number(_r('0 Comments'), _r('1 Comment'), _r('% Comments')); ?></span>
										</a>
									</div>
	
									<?php else : ?>
				
									<div class="readon">
										<span><?php comments_number(_r('0 Comments'), _r('1 Comment'), _r('% Comments')); ?></span>
									</div>
									
									<?php endif; ?>
									
									<!-- End Comments -->
								
								<?php endif; ?>
								
							
							</div>
						</div>
						<div class="clear"></div>
						</div>
				<!-- End Post -->
				
				<?php endwhile;?>
				
				<!-- Begin Navigation -->
											
				<?php global $wp_query; $total_pages = $wp_query->max_num_pages; if($total_pages > 1) : ?>
						
				<div class="rt-pagination nav">
					<div class="alignleft">
						<?php next_posts_link('&laquo; '._r('Older Entries')); ?>
					</div>
					<div class="alignright">
						<?php previous_posts_link(_r('Newer Entries').' &raquo;') ?>
					</div>
					<div class="clear"></div>
				</div><br />
							
				<?php endif; ?>
		
				<!-- End Navigation -->
	
		
	</div>