<?php
/**
 * @version   1.0 February 17, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

// no direct access
?>

<?php global $post, $posts, $query_string; ?>

		<div id="page">
			
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
			<!-- Begin Post -->
					<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
						
						<?php if($gantry->get('page-title')) : ?>
		
						<!-- Begin Title -->
					
							<?php if($gantry->get('page-meta-date')) : ?>
							
							<!-- Begin Date & Time -->
		
							<span class="createdate"><!--<?php _re('Posted on'); ?> --><span><?php the_time('l, d F, Y H:i'); ?></span></span>
							
							<!-- End Date & Time -->
							
							<?php endif; ?>
											
							<h2 class="contentheading">
								<?php the_title(); ?>
							</h2>
							<div class="articledivider"></div>
						
						<div class="clear"></div>
							
						<!-- End Title -->
							
						<?php endif; ?>
						
						<?php if($gantry->get('page-meta-comments') || $gantry->get('page-meta-date') || $gantry->get('page-meta-modified') || $gantry->get('page-meta-author')) : ?>
								
						<!-- Begin Meta -->
						
						<p class="articleinfo">
						
							<?php if($gantry->get('page-meta-modified')) : ?>
							
							<!-- Begin Modified Date -->
		
							<span class="modifydate"><?php _re('Last Updated on'); ?> <?php the_modified_date('l, d F, Y H:i', '<span>', '</span>'); ?></span>
							
							<!-- End Modified Date -->
							
							<?php endif; ?>
								
							<?php if($gantry->get('page-meta-author')) : ?>
						
							<!-- Begin Author -->
						
							<span class="createdby"><?php _re('Written by'); ?> <span><?php the_author(); ?></span></span>
							
							<!-- End Author -->
							
							<?php endif; ?>
							
							<?php if($gantry->get('page-meta-comments')) : ?>
								
							<!-- Begin Comments -->
							
							
							<span class="createdby"><?php comments_number(_r('0 Comments'), _r('1 Comment'), _r('% Comments')); ?></span>
							
							
							<!-- End Comments -->
						
							<?php endif; ?>
							
						</p>
						
						<!-- End Meta -->
						
						<?php endif; ?>

							<!-- Begin Post Content -->		

							<?php the_content(); ?>

							<div class="clear"></div>
							
							<?php wp_link_pages('before=<div class="rt-pagination">'._r('Pages:').'&after=</div><br />'); ?>
																														
							<?php edit_post_link(_r('Edit this entry.'), '<div class="edit-entry">', '</div>'); ?>
								
							<?php if(comments_open() && $gantry->get('page-comments-form')) : ?>

						<a name="comments"></a>
																
						<?php echo $gantry->displayComments(true, $gantry->get('comments-style'), $gantry->get('comments-style')); ?>
					
					<?php endif; ?>
							
							<div class="clear"></div>
							
							<!-- End Post Content -->													
					</div>
					<div class="clear"></div>
			
			
			<!-- End Post -->
			
			<?php endwhile;?>
			
			<?php else : ?>
																		
			<h1 class="rt-pagetitle">
				<?php _re('Sorry, no pages matched your criteria.'); ?>
			</h1>
				
			<?php endif; ?>
			
			<?php wp_reset_query(); ?>

	</div>