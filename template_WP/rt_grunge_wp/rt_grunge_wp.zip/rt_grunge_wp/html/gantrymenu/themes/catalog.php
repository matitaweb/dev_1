<?php
/**
 * @version   1.0 February 17, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
require_once(dirname(__FILE__).'/grunge_splitmenu/theme.php');
GantryWidgetMenu::registerTheme(dirname(__FILE__).'/grunge_splitmenu','grunge_splitmenu', __('Grunge SplitMenu'), 'GrungeSplitMenuTheme');
require_once(dirname(__FILE__).'/grunge_touch/theme.php');
GantryWidgetMenu::registerTheme(dirname(__FILE__).'/grunge_touch','grunge_touch', __('Grunge Touch'), 'GrungeTouchMenuTheme');