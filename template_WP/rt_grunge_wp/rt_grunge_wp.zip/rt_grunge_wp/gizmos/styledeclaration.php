<?php
/**
 * @version   1.0 February 17, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

defined('GANTRY_VERSION') or die();

gantry_import('core.gantrygizmo');

/**
 * @package     gantry
 * @subpackage  features
 */
class GantryGizmoStyleDeclaration extends GantryGizmo {

    var $_name = 'styledeclaration';
    
    function isEnabled(){
        return true;
    }

    function query_parsed_init() {
    
    	global $gantry;
        
        //inline css for dynamic stuff
		$css = '#rt-main-surround ul.menu li.active > a, #rt-main-surround ul.menu li.active > .separator, #rt-main-surround ul.menu li.active > .item, h2.title span, #rt-submenu ul.menu li.active > .item, #rt-submenu .nopill ul.menu li > .item:hover, .menutop li.root:hover > .item, .menutop li.root.f-mainparent-itemfocus > .item, .menu-type-splitmenu .menutop.theme-splitmenu li:hover .item {color:'.$gantry->get('linkcolor').';}'."\n";
		
        $css .= 'body a,#rt-copyright .title, #rt-main-surround .rt-article-title, #rt-main-surround .title, #rt-showcase .title,#rt-feature .title, #rt-showcase .showcase-title span {color:'.$gantry->get('linkcolor').';}';



        $gantry->addInlineStyle($css);
		$this->_disableRokBoxForiPhone();

		//style stuff
        $gantry->addStyle($gantry->get('cssstyle').".css");

	}
	
	function _disableRokBoxForiPhone() {
		global $gantry;
		
		if ($gantry->browser->platform == 'iphone') {
			$gantry->addInlineScript("window.addEvent('domready', function() {\$\$('a[rel^=rokbox]').removeEvents('click');});");
		}
	}
	
}