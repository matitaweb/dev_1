<?php
/**
 * @version   1.0 February 17, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */


$form = '<div class="search"><form method="get" id="mod_search_searchword" action="' . home_url( '/' ) . '" >
	<input type="submit" class="button" id="searchsubmit" value="'. esc_attr__('Search') .'" />
        <input class="inputbox" type="text" value="' . get_search_query() . '" name="s" id="s" />
	</form></div>';

	if ( $echo )
		echo apply_filters('get_search_form', $form);
	else
		return apply_filters('get_search_form', $form);
?>