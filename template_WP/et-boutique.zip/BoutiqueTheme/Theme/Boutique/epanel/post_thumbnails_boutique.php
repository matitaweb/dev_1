<?php

/* sets predefined Post Thumbnail dimensions */
if ( function_exists( 'add_theme_support' ) ) {
   add_theme_support( 'post-thumbnails' );
      
   add_image_size( 'et-product', 113, 96, true );
   add_image_size( 'et-blogpost', 249, 244, true );
   add_image_size( 'et-special-offer', 137, 121, true );
   add_image_size( 'et-featured', 380, 230, true );
   add_image_size( 'et-page', 200, 200, true );
  
   
   //blog page template
   add_image_size( 'ptentry-thumb', 184, 184, true );
   //gallery page template
   add_image_size( 'ptgallery-thumb', 207, 136, true );
   //portfolio page template
   add_image_size( 'ptportfolio-thumb', 260, 170, true );
   add_image_size( 'ptportfolio-thumb2', 260, 315, true );
   add_image_size( 'ptportfolio-thumb3', 140, 94, true );
   add_image_size( 'ptportfolio-thumb4', 140, 170, true );
   add_image_size( 'ptportfolio-thumb5', 430, 283, true );
   add_image_size( 'ptportfolio-thumb6', 430, 860, true );
};
/* --------------------------------------------- */

?>