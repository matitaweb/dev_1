<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
?>
			<?php $option = get_option('novus-options'); ?>
			
			<!-- Begin Left Sidebar -->
	
			<div id="sidecol">
				<div id="side-column">
					<div class="padding">
						<div class="inner">
						
							<!-- Begin Over Left Subpage Sidebar -->
									
							<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Over Left Subpage Sidebar') ) : ?>
							<?php endif; ?>
				
							<!-- End Over Left Subpage Sidebar -->
                      	                  
                      	 	<!-- Begin Left Subpage Sidebar -->
                                        	
                            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Left Subpage Sidebar') ) : ?>
                          	             
							<?php include(TEMPLATEPATH . '/includes/' . $option['left_sub_side_file']); ?>
											
							<?php endif; ?>
											
							<!-- End Left Subpage Sidebar -->
											
							<!-- Begin Under Left Subpage Sidebar -->
				
							<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Under Left Subpage Sidebar') ) : ?>
							<?php endif; ?>
				
							<!-- End Under Left Subpage Sidebar -->
							
						</div>
					</div>
				</div>
			</div>
			
			<!-- End Left Sidebar -->