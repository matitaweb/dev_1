<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

// Theme Features Init

add_action('after_setup_theme', 'rok_theme_setup');

function rok_theme_setup() {

	$wp_ver = get_bloginfo('version');

	if (function_exists('add_theme_support')) {
		
		if($wp_ver >= 3.0) {
	
			// Add default posts and comments RSS feed links to head
			
			add_theme_support('automatic-feed-links');
			
			// This theme uses wp_nav_menu() in one location.
			
			register_nav_menus( array(
				'top_nav' => _r('Top Navigation'),
			) );
			
			// Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
			
			/*function rok_theme_page_menu_args($args='') {
				$args['show_home'] = true;
				return $args;
			}
			
			add_filter('wp_nav_menu_args', 'rok_theme_page_menu_args');*/
			
			function rok_theme_page_menu_link($item) {
				$item = str_replace('current_page_item', 'current_page_item active', $item);		
				return $item;
			}
			
			add_filter('nav_menu_css_class', 'rok_theme_page_menu_link');
			
			function  rok_theme_page_menu_a_class($output) {
				$output = str_replace('<a', '<a class="link"', $output);
				return $output;
			}
			
			add_filter('walker_nav_menu_start_el', 'rok_theme_page_menu_a_class');
	
		}
		
	}
	
}

// Menu backwards compatibility

function rok_old_menu() { 
		
	$option = get_option('novus-options');
	
	?>
	
	<ul class="menu">
					
	<?php if ($option['top_menu_home'] == 'true') { ?>

		<li class="home<?php if ( is_front_page() ) echo ' active';?>" <?php if ( is_front_page() ) echo 'id="current"';?>><a href="<?php bloginfo('url'); ?>/" class="link"><span><?php _re('Home'); ?></span></a></li>
				
	<?php } ?>
				
	<?php
	
	$my_pages = wp_list_pages('echo=0&title_li=&link_before=<span>&link_after=</span>&sort_column='.$option['top_menu_sorting'].'&depth=1&exclude='.$option['top_menu_exclude']);

	$my_pages = str_replace("current_page_item", 'active', $my_pages);
	$my_pages = str_replace("<a", '<a class="link"', $my_pages);

	echo $my_pages;
			
	?>
					
	</ul>

	<?php
			
}

// Enable shortcodes in widgets

add_filter('widget_text', 'do_shortcode');

// Sample Data Import Helper

add_action('import_start', 'rt_change_path');
add_action('import_end', 'rt_unlink_file');

function rt_change_path() {
	global $wp_import;
	
	$xml = file_get_contents($wp_import->file);
	$xml = preg_replace("/\@RT_SITE_URL\@/", get_bloginfo('wpurl'), $xml);

	$temp = tempnam(sys_get_temp_dir(), "rt_wp_import");
	$handle = fopen($temp, "w");
	fwrite($handle, $xml);
	$wp_import->file = $temp;
	fclose($handle);
}

function rt_unlink_file() {
	global $wp_import;
	
	unlink($wp_import->file);
}

// WordPress 2.9 Post Image

$wp_ver = get_bloginfo('version');
if (function_exists('add_theme_support') && $wp_ver >= 2.9) { 
	$option = get_option('novus-options');
	add_theme_support('post-thumbnails');
	set_post_thumbnail_size($option['thumb_width'], $option['thumb_height'], true);
}

// Layout Ninja

function layout_ninja() {

	$option = get_option('novus-options');

	$layout_option = $option['layout_front'];
	$layout_option_subpage = $option['layout_subpage'];

	switch($layout_option) {
		case 's-c-x':
			$option['left_front_sidebar'] = 'true';
			update_option('novus-options', $option);
            break;
        case 'x-c-x':
			$option['left_front_sidebar'] = 'false';
			update_option('novus-options', $option);
            break;
	}
	switch($layout_option_subpage) {
		case 's-c-x':
			$option['left_sub_sidebar'] = 'true';
			update_option('novus-options', $option);
            break;
        case 'x-c-x':
			$option['left_sub_sidebar'] = 'false';
			update_option('novus-options', $option);
            break;
	}
}

add_action('init', 'layout_ninja');

// IE version checker

function rok_isIe($version = false) {   

	$agent=$_SERVER['HTTP_USER_AGENT'];  

	$found = strpos($agent,'MSIE ');  
	if ($found) { 
	        if ($version) {
	            $ieversion = substr(substr($agent,$found+5),0,1);   
	            if ($ieversion == $version) return true;
	            else return false;
	        } else {
	            return true;
	        }

        } else {
                return false;
        }
	if (stristr($agent, 'msie'.$ieversion)) return true;
	return false;        
}

// Language Handler

rockettheme_translation();

function rockettheme_translation() {
	global $tname;
	load_theme_textdomain($tname.'_lang');
}

function _r($str) {
	global $tname;
	return __($str, $tname.'_lang');
}

function _re($str) {
	global $tname;
	_e($str, $tname.'_lang');
}

if (!function_exists ("mysql_real_escape_string")) {
	function mysql_real_escape_string ($str) {
		return mysql_escape_string ($str);
	}
}

// Update default frontpage post count

if ( is_admin() && isset($_GET['activated'] ) && $pagenow == 'themes.php' ) {
	update_option( 'posts_per_page', 3 );
}

// Catch first image from post

function catch_that_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];

  return $first_img;
}

// WordPress MU Styling

function mu_signup_css() { ?>
	<style type="text/css">
	.widecolumn .entry p {font-size: 1.05em;}
	.widecolumn {line-height: 1.6em;}
	.widecolumn {padding: 10px 0 20px 0;margin: 0 auto;width: 450px; margin-bottom: 30px;}
	.widecolumn .post {margin: 0;}
	</style>
<?php }
 
function mu_add_signup_css () { 
	add_action('wp_head','mu_signup_css', 99);
}

add_action('signup_header','mu_add_signup_css');

?>