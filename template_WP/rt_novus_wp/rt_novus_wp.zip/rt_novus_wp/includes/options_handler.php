<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

function theme_options_init() {

	global $tname;
	
	$new_options = array(

		// Dimensions
		
		'site_width' => '950',
		'left_sidebar_w' => '25',
		
		// Layout
		
		'layout_front' => 's-c-x',
		'layout_subpage' => 's-c-x',
		
		'left_front_sidebar' => 'true',
		
		'left_sub_sidebar' => 'true',
		
		'left_front_side_file' => 'side-front-left.php',
		
		'left_sub_side_file' => 'side-sub-left.php',
		
		// Left Sidebar
		
		'sidebar_left_front_categories' => 'true',
		'sidebar_left_front_categories_order' => 'name',
		'sidebar_left_front_categories_empty' => '1',
		'sidebar_left_front_categories_exclude' => '',
		
		'sidebar_left_front_archives' => 'true',
		'sidebar_left_front_archives_type' => 'monthly',
		'sidebar_left_front_archives_limit' => '12',
		
		'sidebar_left_front_tags' => 'true',
		'sidebar_left_front_tags_order' => 'name',
		
		// Left Subpage Sidebar
		
		'sidebar_left_sub_categories' => 'true',
		'sidebar_left_sub_categories_order' => 'name',
		'sidebar_left_sub_categories_empty' => '1',
		'sidebar_left_sub_categories_exclude' => '',
		
		'sidebar_left_sub_archives' => 'true',
		'sidebar_left_sub_archives_type' => 'monthly',
		'sidebar_left_sub_archives_limit' => '12',
		
		'sidebar_left_sub_tags' => 'true',
		'sidebar_left_sub_tags_order' => 'name',
		
		// Top
		
		'site_logo' => 'true',
		
		// Top Menu
		
		'top_menu' => 'true',
		'top_menu_home' => 'true',
		'top_menu_sorting' => 'menu_order',
		'top_menu_exclude' => '',
		
		// Blog
		
		'blog_order' => 'date',
		'blog_content' => 'content',
		'blog_cat' => '',
		
		'blog_title' => 'true',
		'blog_title_link' => 'false',
		
		'blog_meta' => 'true',
		'blog_comments' => 'true',
		'blog_author' => 'true',
		'blog_date' => 'true',
		
		'blog_recent' => 'true',
		'blog_popular' => 'true',
		'blog_topmod_count' => '5',
		
		'blog_blogroll' => 'true',
		'blog_blogroll_order' => 'name',
		'blog_blogroll_limit' => '-1',
		'blog_blogroll_category' => '',
		
		'blog_search' => 'true',
		
		// Single
		
		'single_title' => 'true',
		
		'single_meta' => 'true',
		'single_meta_author' => 'true',
		'single_meta_date' => 'true',
		'single_meta_comments' => 'true',
		'single_footer' => 'true',
		
		'single_tweetmeme' => 'true',
		
		// Page
		
		'page_title' => 'true',
		
		'page_meta' => 'false',
		'page_meta_author' => 'true',
		'page_meta_date' => 'true',
		'page_meta_comments' => 'true',
		
		'page_tweetmeme' => 'false',
		
		// Archive
		
		'category_postcount' => '5',
		'category_contentdis' => 'content',
		'category_postmeta' => 'true',
		'category_postmeta_author' => 'true',
		'category_postmeta_date' => 'true',
		'category_postmeta_comments' => 'true',
		'category_title' => 'true',
		'category_titlelink' => 'false',
		'category_blogroll' => 'true',	
		'category_search' => 'true',
		
		'archive_postcount' => '5',
		'archive_contentdis' => 'content',
		'archive_postmeta' => 'true',
		'archive_postmeta_author' => 'true',
		'archive_postmeta_date' => 'true',
		'archive_postmeta_comments' => 'true',
		'archive_title' => 'true',
		'archive_titlelink' => 'false',
		'archive_blogroll' => 'true',
		'archive_search' => 'true',
		
		'tag_postcount' => '5',
		'tag_contentdis' => 'content',
		'tag_postmeta' => 'true',
		'tag_postmeta_author' => 'true',
		'tag_postmeta_date' => 'true',
		'tag_postmeta_comments' => 'true',
		'tag_title' => 'true',
		'tag_titlelink' => 'false',
		'tag_blogroll' => 'true',	
		'tag_search' => 'true',
		
		// Search
		
		'search_postcount' => '5',
		'search_contentdis' => 'content',
		'search_postmeta' => 'true',
		'search_postmeta_author' => 'true',
		'search_postmeta_date' => 'true',
		'search_postmeta_comments' => 'true',
		'search_title' => 'true',
		'search_titlelink' => 'false',
		'search_blogroll' => 'true',		
		'search_search' => 'true',
		
		// Footer
		
		'footer_enabled' => 'true',
		
		'footer_logo' => 'true',
		
		// Other
		
		'thumb_width' => '85',
		'thumb_height' => '85',
		
		'font_size' => 'f-default',
		
		// RokBox
		
		'rokbox_enabled' => 'true',
		'rokbox_style' => 'light'
		
	);

	add_option($tname.'-options', $new_options);
}

add_action('init', 'theme_options_init');

function register_theme_settings() {

	global $tname;
	
	register_setting('theme-options-array', $tname.'-options');
	
}

if (is_admin()) {

add_action('admin_init', 'register_theme_settings');

}

?>