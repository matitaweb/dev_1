<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */ 

$option = get_option('moxy-options');

if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'Header',
    	'id' => 'header',
    	'description' => _r('Widget position directly under Logo'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'User 1',
    	'id' => 'user_1',
    	'description' => _r('Position directly over the main content - full width.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'User 2',
    	'id' => 'user_2',
    	'description' => _r('Position directly over the main content - 50% width.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'User 3',
    	'id' => 'user_3',
    	'description' => _r('Position directly over the main content - 50% width.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'User 4',
    	'id' => 'user_4',
    	'description' => _r('Position directly under the main content - 50% width.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'User 5',
    	'id' => 'user_5',
    	'description' => _r('Position directly under the main content - 50% width.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'Over Left Front Sidebar',
    	'id' => 'over_left_front_sidebar',
    	'description' => _r('Over the default content of the left frontpage sidebar.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s"><div class="moduletable_menu">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'Left Front Sidebar',
    	'id' => 'left_front_sidebar',
    	'description' => _r('Widgets placed here will replace the default content of the left frontpage sidebar.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s"><div class="moduletable_menu">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'Under Left Front Sidebar',
    	'id' => 'under_left_front_sidebar',
    	'description' => _r('Under the default content of the left frontpage sidebar.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s"><div class="moduletable_menu">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'Over Left Subpage Sidebar',
    	'id' => 'over_left_subpage_sidebar',
    	'description' => _r('Over the default content of the left subpage sidebar.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s"><div class="moduletable_menu">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'Left Subpage Sidebar',
    	'id' => 'left_subpage_sidebar',
    	'description' => _r('Widgets placed here will replace the default content of the left subpage sidebar.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s"><div class="moduletable_menu">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
if ( function_exists('register_sidebars') )
    register_sidebars(1, array(
    	'name' => 'Under Left Subpage Sidebar',
    	'id' => 'under_left_subpage_sidebar',
    	'description' => _r('Under the default content of the left subpage sidebar.'),
        'before_widget' => '<div id="%1$s" class="widget %2$s"><div class="moduletable_menu">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
   
?>