<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
?>
		<?php $option = get_option('novus-options'); ?>
		
		<?php if($option['footer_enabled'] == 'true') { ?>
		
		<!-- Begin Footer -->
				
		<div id="bottom">
			<div class="wrapper">
				<div align="center">
				
					<?php if($option['footer_logo'] == 'true') { ?>
				
					<!-- Begin Logo -->
				
					<a href="http://www.rockettheme.com/" title="RocketTheme WordPress Template Club" class="nounder"><img src="<?php bloginfo('template_directory'); ?>/images/blank.gif" alt="RocketTheme WordPress Templates" id="rocket" /></a>
					
					<!-- End Logo -->
					
					<?php } ?>
					
				</div>
			</div>
		</div>
		
		<!-- End Footer -->
		
		<?php } ?>
		
		<?php wp_footer(); ?>
		
	</body>	
</html>