<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
?>
			<?php $option = get_option('novus-options'); ?>
			
			<!-- Begin Left Sidebar -->
	
			<div id="sidecol">
				<div id="side-column">
					<div class="padding">
						<div class="inner">
						
							<!-- Begin Over Left Front Sidebar -->
									
							<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Over Left Front Sidebar') ) : ?>
							<?php endif; ?>
				
							<!-- End Over Left Front Sidebar -->
                      	                  
                      	 	<!-- Begin Left Front Sidebar -->
                                        	
                            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Left Front Sidebar') ) : ?>
                          	             
							<?php include(TEMPLATEPATH . '/includes/' . $option['left_front_side_file']); ?>
											
							<?php endif; ?>
											
							<!-- End Left Front Sidebar -->
											
							<!-- Begin Under Left Front Sidebar -->
				
							<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Under Left Front Sidebar') ) : ?>
							<?php endif; ?>
				
							<!-- End Under Left Front Sidebar -->
							
						</div>
					</div>
				</div>
			</div>
			
			<!-- End Left Sidebar -->