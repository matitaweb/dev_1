<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
?>
<?php $option = get_option('novus-options'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
	<head>
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
		<meta name="description" content="<?php bloginfo('description'); ?>" />
		
		<title>
			<?php 
		
			// Returns the title based on what is being viewed
			
			// Single posts
			if (is_single()) { 
				single_post_title(); echo ' | '; bloginfo('name');
			
			// The home page or, if using a static front page, the blog posts page.		
			} elseif (is_home() || is_front_page()) {
				bloginfo('name');
				if( get_bloginfo('description'))
					echo ' | ' ; bloginfo('description');
					
			// WordPress Pages
			} elseif (is_page()) {	
				single_post_title(''); echo ' | '; bloginfo('name');
				
			// Search results
			} elseif (is_search()) {
				printf(_r('Search results for %s'), '"'.get_search_query().'"'); echo ' | '; bloginfo('name');
				
			// 404 (Not Found)
			} elseif (is_404()) {
				_re('Not Found'); echo ' | '; bloginfo('name');
				
			// Otherwise:
			} else {
				wp_title(''); echo ' | '; bloginfo('name');
			}
			
			?>
		</title>
		
		<link rel="profile" href="http://gmpg.org/xfn/11" />
		
		<?php
		
		$wp_ver = get_bloginfo('version');
			
		if ($wp_ver < 3.0) {
			
		?>
		
		<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
		<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
		<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
		
		<?php } ?>
		
		<?php if ($option['rokbox_enabled'] == 'true') { ?>
		
		<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/js/rokbox/themes/<?php echo $option['rokbox_style']; ?>/rokbox-style.css" type="text/css" />
		
		<!--[if lte IE 6]>
			<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/js/rokbox/themes/<?php echo $option['rokbox_style']; ?>/rokbox-style-ie6.css" type="text/css" />
		<![endif]-->
		<!--[if IE 7]>
			<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/js/rokbox/themes/<?php echo $option['rokbox_style']; ?>/rokbox-style-ie7.css" type="text/css" />
		<![endif]-->
		<!--[if IE 8]>
			<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/js/rokbox/themes/<?php echo $option['rokbox_style']; ?>/rokbox-style-ie8.css" type="text/css" />
		<![endif]-->
		
		<?php } ?>
		
		<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/mootools.js"></script>

		<link href="<?php bloginfo('template_directory'); ?>/css/template_css.css" rel="stylesheet" type="text/css" />
		<link href="<?php bloginfo('template_directory'); ?>/css/wp.css" rel="stylesheet" type="text/css" />
		
		<style type="text/css">
			body {min-width: <?php echo $option['site_width']; ?>px;}
			div.wrapper { margin: 0 auto; width: <?php echo $option['site_width']; ?>px;}
			.s-c-x #sidecol { width: <?php echo $option['left_sidebar_w']; ?>%;}
			.s-c-x #main-column { margin-left: <?php echo $option['left_sidebar_w']; ?>%;}
			.x-c-x #sidecol { width: 0;}
			.x-c-x #main-column { margin-left: 0;}
		</style>
		
		<?php if (rok_isIe(6)) :?>
			
			<!--[if lte IE 6]>
				<link href="<?php bloginfo('template_directory'); ?>/css/template_ie6.css" rel="stylesheet" type="text/css" />
				<style type="text/css">
				img { behavior: url(<?php bloginfo('template_directory'); ?>/css/iepngfix.htc); } 
				</style>
			<![endif]-->
			
		<?php endif; ?>
		
		<?php if (rok_isIe()) :?>
		
		<!--[if IE 7]>
			<link href="<?php bloginfo('template_directory'); ?>/css/template_ie7.css" rel="stylesheet" type="text/css" />
		<![endif]-->
		
		<!--[if IE 8]>
			<link href="<?php bloginfo('template_directory'); ?>/css/template_ie8.css" rel="stylesheet" type="text/css" />
		<![endif]-->
		
		<?php endif; ?>
		
		<?php if ($option['rokbox_enabled'] == 'true') { ?>
  		
  			<script type="text/javascript">var rokboxPath = "<?php bloginfo('template_directory'); ?>/js/rokbox/";</script>
  			<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/rokbox/rokbox.js"></script>
  			<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/rokbox/themes/<?php echo $option['rokbox_style']; ?>/rokbox-config.js"></script>
  			
  		<?php } ?>
  		
  		<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
		
		<?php wp_head(); ?>
	
	</head>
	
	<body class="<?php echo $option['font_size']; ?>">
	
		<?php if($option['top_menu'] == 'true') { ?>
		
		<!-- Begin Menu Bar -->
		
		<div id="menu-bar">
			<div class="wrapper">
				<div id="horiz-menu" class="splitmenu">
				
					<?php if(function_exists('wp_nav_menu')) {
					
					wp_nav_menu( array('menu' => 'Top Navigation', 'container' => 'ul', 'menu_class' => 'menu', 'depth' => '1', 'fallback_cb' => 'rok_old_menu', 'link_before' => '<span>', 'link_after' => '</span>' ));
					
					} else {
					
					rok_old_menu();
					
					} ?>
					
				</div>
			</div>
		</div>
		
		<!-- End Menu Bar -->
		
		<?php } ?>
		
		<!-- Begin Logo And Header Widget -->
		
		<div id="inset">
			<div class="wrapper">
			
				<?php if ($option['site_logo'] == 'true') { ?>
			
				<!-- Begin Logo -->
			
				<a href="<?php bloginfo('url'); ?>" class="nounder">
					<img src="<?php bloginfo('template_directory'); ?>/images/blank.gif" style="border:0;" alt="" id="logo" />
				</a>
				
				<!-- End Logo -->
				
				<?php } ?>
				
				<?php if(is_active_sidebar('header')) { ?>
				
				<!-- Begin Header Widget -->
				
				<div class="content">
				
					<?php dynamic_sidebar('Header'); ?>
				
				</div>
				
				<!-- End Header Widget -->
				
				<?php } ?>
				
			</div>
		</div>
		
		<!-- End Logo And Header Widget -->