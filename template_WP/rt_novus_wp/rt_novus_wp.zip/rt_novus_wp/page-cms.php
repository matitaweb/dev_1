<?php
/*
Template Name: FrontPage - CMS
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
*/
?>

<?php get_header(); ?>

		<?php $option = get_option('novus-options'); ?>
	
		<div id="content" class="<?php echo $option['layout_front']; ?>">
			<div class="wrapper">
			
				<!-- Begin Left Column (col2) -->
					        		
				<?php if($option['left_front_sidebar'] == 'true') { ?>
							    		
				<?php get_sidebar('left'); ?>
										
				<?php } ?>
					         
				<!-- End Left Column (col2) -->	
								
				<div id="main-column">
					<div class="padding">
						<div class="inner">
						
							<?php if(is_front_page() && is_active_sidebar('user_1')) { ?>
						
							<!-- Begin User 1 Widget Position -->
						
							<div id="top">
								<div class="moduletable">
									
									<?php dynamic_sidebar('User 1'); ?>
									
								</div>
							</div>
							
							<!-- End User 1 Widget Position -->
							
							<?php } ?>
							
							<?php if(is_front_page() && ($option['blog_recent'] == 'true' || $option['blog_popular'] == 'true' || is_active_sidebar('user_2') || is_active_sidebar('user_3'))) { ?>
							
							<!-- Begin User 2 And User 3 Widget Positions -->
							
							<div id="topmodules" class="spacer w49">
							
								<?php if(is_active_sidebar('user_2') || $option['blog_recent'] == 'true') { ?>
								
								<!-- Begin User 2 Widget Position -->
							
								<div class="block">
									<div class="moduletable">
									
										<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('User 2')) : ?>
									
										<h3>
											<?php _re('Recent Posts'); ?>
										</h3>
										<ul class="latestnews">
											
											<?php wp_get_archives('title_li=&type=postbypost&limit='.$option['blog_topmod_count']); ?>
											
										</ul>
										
										<?php endif; ?>
										
									</div>
								</div>
								
								<!-- End User 2 Widget Position -->
								
								<?php } ?>
								
								<?php if(is_active_sidebar('user_3') || $option['blog_popular'] == 'true') { ?>
								
								<!-- Begin User 3 Widget Position -->
								
								<div class="block">
									<div class="moduletable">
									
										<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('User 3')) : ?>
										
										<?php $wp_ver = get_bloginfo('version'); ?>
										
										<h3>
											<?php _re('Popular'); ?>
										</h3>
										
										<?php if($wp_ver >= 2.9) { ?>
											
											<ul class="mostread">
											
												<?php query_posts('showposts='.$option['blog_topmod_count'].'&orderby=comment_count&order=DESC') ?>
												<?php while (have_posts()) : the_post(); ?>									
				
												<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
				
												<?php endwhile; ?>
												
												<?php wp_reset_query(); ?>
												
											</ul>
											
										<?php } else { ?>
											
											<ul class="mostread">
												<?php $result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , ".$option['blog_topmod_count']);
												foreach ($result as $post) {
												setup_postdata($post);
												$postid = $post->ID;
												$title = $post->post_title;
												$commentcount = $post->comment_count;
												if ($commentcount != 0) { ?>
												<li><a href="<?php echo get_permalink($postid); ?>" title="<?php echo $title ?>"><?php echo $title ?></a></li>
												<?php } } ?>
											</ul>
											
										<?php } ?>
										
										<?php endif; ?>
										
									</div>
								</div>
								
								<!-- End User 3 Widget Position -->
								
								<?php } ?>
								
							</div>
							
							<!-- End User 2 And User 3 Widget Positions -->
							
							<?php } ?>
							
							<div class="contentpadding">	
								<div class="blog page-cms">
								
									<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
									
									<!-- Begin Post -->

									<div class="contentpaneopen">		
										<div <?php post_class('blog-post'); ?> id="post-<?php the_ID(); ?>">
										
											<?php if ($option['page_title'] == 'true') { ?>
											
											<!-- Begin Title -->
										
											<div class="article-rel-wrapper">
													
												<span class="contentheading">
													<?php the_title(); ?>
												</span>
													
											</div>
												
											<!-- End Title -->
												
											<?php } ?>
											
											<?php if ($option['page_meta'] == 'true') { ?>
											
											<!-- Begin Meta -->
											
											<div class="article-info-surround">
											
												<?php if ($option['page_author'] == 'true') { ?>

													<div class="createdby small">
														<?php the_author(); ?>
													</div>

												<?php } ?>
												
												<?php if ($option['page_date'] == 'true') { ?>
												
												<div class="createdate small">
													<?php the_time('l, d F Y H:i'); ?>	
												</div>
												
												<?php } ?>
												
												<?php if ($option['page_comments'] == 'true') { ?>
												
												<div class="post_comments small">
													<a title="<?php comments_number(_r('No Comments'), _r('1 Comment'), _r('% Comments')); ?>" href="<?php the_permalink(); ?>#comments">
														<?php comments_number(_r('No Comments'), _r('1 Comment'), _r('% Comments')); ?>
													</a>	
												</div>
												
												<?php } ?>
												
											</div>

											<!-- End Meta -->
											
											<?php } ?>

											<!-- Begin Content -->
												
											<div class="main-text">
													
												<?php if($option['page_tweetmeme'] == 'true') { ?>
	    																									
												<div class="tweetmeme png"><script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script></div>
																					
												<?php } ?>
																	
												<?php the_content(); ?>
												
												<div class="clr"></div>
													
												<?php wp_link_pages('before=<div class="pagination"><span class="pagination-name">'._r('Pages:').'</span><span class="pagination-numbers">&after=</span></div><br />'); ?>
																											
												<?php edit_post_link(_r('Edit this entry.'), '', ''); ?>
												
												<?php if(comments_open()) { ?>
													
												<a name="comments"></a>
																						
												<?php comments_template(); ?>
												
												<?php } ?>
													
											</div>
												
											<div class="clr"></div>
											
											<!-- End Content -->

										</div>
									</div>
									<span class="article_separator">&nbsp;</span>
									
									<!-- End Post -->
									
									<?php endwhile; ?>
																
									<?php else : ?>
										
									<span class="attention"><?php _re('Sorry, no pages matched your criteria.'); ?></span>
										
									<?php endif; ?>
									
								</div>
							</div>
							
							<?php if($option['blog_search'] == 'true' || $option['blog_blogroll'] == 'true' || is_active_sidebar('user_4') || is_active_sidebar('user_5')) { ?>
							
							<!-- Begin Bottom Widgets -->
							
							<div id="bottommodules" class="spacer w49">
							
								<?php if($option['blog_blogroll'] == 'true' || is_active_sidebar('user_4')) { ?>
								
								<!-- Begin User 4 Widget -->
							
								<div class="block">
									<div class="moduletable">
									
										<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('User 4')) : ?>
									
										<ul id="mainlevel-nav">
											
											<?php wp_list_bookmarks('title_li=&orderby='.$option['blog_blogroll_order'].'&limit='.$option['blog_blogroll_limit'].'&link_before=<span>&link_after=</span>&categorize=0&category='.$option['blog_blogroll_category']); ?>
											
										</ul>
										
										<?php endif; ?>
										
									</div>
								</div>
								
								<!-- End User 4 Widget -->
								
								<?php } ?>
								
								<?php if($option['blog_search'] == 'true' || is_active_sidebar('user_5')) { ?>
								
								<!-- Begin User 5 Widget -->
								
								<div class="block">
									<div class="moduletable">
									
										<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('User 5')) : ?>
									
										<form name="roksearch" id="roksearch" class="inputbox" action="<?php bloginfo('home'); ?>/" method="get">
											<div class="rokajaxsearch">
												<input id="roksearch_search_str" name="s" type="text" class="inputbox" value=" <?php _re('Search...'); ?>" onblur="if(this.value=='') this.value=' <?php _re('Search...'); ?>';" onfocus="if(this.value==' <?php _re('Search...'); ?>') this.value='';" />
												<input type="hidden" name="task" value="search" />
											</div>
										</form>
										
										<?php endif; ?>
										
									</div>
								</div>
								
								<!-- End User 5 Widget -->
								
								<?php } ?>
								
							</div>
							
							<div class="clr"></div>
							
							<!-- End Bottom Widgets -->
							
							<?php } ?>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="clr"></div>
	
<?php get_footer(); ?>