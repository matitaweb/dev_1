<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
?>
<?php

	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'general.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

?>

	<?php $option = get_option('novus-options'); ?>	
	
	<div class="general-wrapper">

		<div class="tabbar">
		
			<div class="tab1 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#main"><?php _re('Main'); ?></a></div>
			</div>
			
			<div class="tab2 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#blog"><?php _re('Blog'); ?></a></div>
			</div>
			
			<div class="tab3 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#topmenu"><?php _re('Top Menu'); ?></a></div>
			</div>
			
			<div class="tab4 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#footer"><?php _re('Footer'); ?></a></div>
			</div>
			
			<div class="tab5 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#dimensions"><?php _re('Dimensions'); ?></a></div>
			</div>
			
			<div class="tab6 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#rokbox"><?php _re('RokBox'); ?></a></div>
			</div>
	
		</div>
		<div class="clr"></div>
					
		<div class="main-general">
		
		<div class="inner-tabber">	
			<a name="main"></a>
			
			<span class="section-title"><?php _re('Main'); ?></span><br /><br />
		
			<table class="options_table">
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Top Logo:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="site_logo"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[site_logo]" id="site_logo" <?php if($option['site_logo'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="site_logo" for="site_logo"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-logo_enabled]"><span class="help">Help</span></a>
							</div>
							<div id="op-logo_enabled" class="rthide"><?php _re('Displays site logo in header.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Font Size:'); ?>
							</div>
							<div class="paramcheck">
								<label class="font_size">
									<select id="font_size" name="novus-options[font_size]">
      			     					<option value="f-smaller" <?php if ($option['font_size'] == "f-smaller") : ?>selected="selected"<?php endif; ?>><?php _re('Smaller'); ?></option>
      			     					<option value="f-default" <?php if ($option['font_size'] == "f-default") : ?>selected="selected"<?php endif; ?>><?php _re('Default'); ?></option>
      			   						<option value="f-larger" <?php if ($option['font_size'] == "f-larger") : ?>selected="selected"<?php endif; ?>><?php _re('Larger'); ?></option>
                   					</select>
                   				</label>
                   				<a href="#" rel="rokbox[350 50][module=op-font-size]"><span class="help">Help</span></a>
							</div>
							<div id="op-font-size" class="rthide"><?php _re('Choose the font size you wish to use on your site.'); ?></div>
						</div>
					</td>
				</tr>
			</table>
			</div>
			
			<div class="inner-tabber">
			<a name="blog"></a>
			
			<span class="section-title"><?php _re('Blog'); ?></span><br /><br />
		
			<table class="options_table">
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Blog Post Order:'); ?>
							</div>
							<div class="paramcheck">
								<label class="blog_order">
									<select id="blog_order" name="novus-options[blog_order]">
      			   						<option value="author" <?php if ($option['blog_order'] == "author") : ?>selected="selected"<?php endif; ?>><?php _re('Author'); ?></option>    	
      			   						<option value="date" <?php if ($option['blog_order'] == "date") : ?>selected="selected"<?php endif; ?>><?php _re('Date'); ?></option> 
      			   						<option value="title" <?php if ($option['blog_order'] == "title") : ?>selected="selected"<?php endif; ?>><?php _re('Title'); ?></option> 
      			   						<option value="modified" <?php if ($option['blog_order'] == "modified") : ?>selected="selected"<?php endif; ?>><?php _re('Modified'); ?></option> 
      			   						<option value="ID" <?php if ($option['blog_order'] == "ID") : ?>selected="selected"<?php endif; ?>>ID</option>
      			   						<option value="rand" <?php if ($option['blog_order'] == "rand") : ?>selected="selected"<?php endif; ?>><?php _re('Random'); ?></option> 		    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 50][module=op-blog_orderby]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_orderby" class="rthide"><?php _re('Here you can change in what order your posts will be displayed on the front page.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Display Posts'); ?>
							</div>
							<div class="paramcheck">
								<label class="blog_content">
									<select id="blog_content" name="novus-options[blog_content]">
      			   						<option value="content" <?php if ($option['blog_content'] == "content") : ?>selected="selected"<?php endif; ?>><?php _re('Content'); ?></option>    	
      			   						<option value="excerpt" <?php if ($option['blog_content'] == "excerpt") : ?>selected="selected"<?php endif; ?>><?php _re('Excerpt'); ?></option> 	    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 50][module=op-blog_content]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_content" class="rthide"><?php _re('Here you can change whether blog should display posts content or excerpt.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Blog Category ID:'); ?>
							</div>
							<div class="paramcheck">
								<label class="blog_cat">
									<input class="textbox" id="blog_cat" type="text" size="15" maxlength="255" name="novus-options[blog_cat]" value="<?php echo $option['blog_cat']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[450 110][module=op-blog_cat]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_cat" class="rthide"><?php _re('Here you can set the categories IDs that should be displayed on the blog page. Also you can exclude the categories from being displayed on the blog page by setting the - (minus) character before the category ID.<br /><b>Please remember that all category IDs should be separated by the comma!</b>'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Display Post Title:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_title"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_title]" id="blog_title" <?php if($option['blog_title'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_title" for="blog_title"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_post_title]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_post_title" class="rthide"><?php _re('Displays post title in the blog view.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Link Post Title:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_title_link"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_title_link]" id="blog_title_link" <?php if($option['blog_title_link'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_title_link" for="blog_title_link"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_post_title_link]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_post_title_link" class="rthide"><?php _re('Link post titles in the blog view.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Post Meta:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_meta"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_meta]" id="blog_meta" <?php if($option['blog_meta'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_meta" for="blog_meta"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_post_meta]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_post_meta" class="rthide"><?php _re('Displays post meta in the blog view.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Comments Count:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_comments"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_comments]" id="blog_comments" <?php if($option['blog_comments'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_comments" for="blog_comments"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_comments]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_comments" class="rthide"><?php _re('Displays comments count in meta in the blog view.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Post Date:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_date"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_date]" id="blog_date" <?php if($option['blog_date'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_date" for="blog_date"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_date]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_date" class="rthide"><?php _re('Displays post date in meta in the blog view.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Post Author:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_author"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_author]" id="blog_author" <?php if($option['blog_author'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_author" for="blog_author"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_author]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_author" class="rthide"><?php _re('Displays post author in meta in the blog view.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Recent Posts:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_recent"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_recent]" id="blog_recent" <?php if($option['blog_recent'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_recent" for="blog_recent"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_recent]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_recent" class="rthide"><?php _re('Displays recent posts directly over blog area.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Popular Posts:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_popular"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_popular]" id="blog_popular" <?php if($option['blog_popular'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_popular" for="blog_popular"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_popular]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_popular" class="rthide"><?php _re('Displays popular posts directly over blog area.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Top Post Count:'); ?>
							</div>
							<div class="paramcheck">
								<label class="blog_topmod_count">
									<input class="textbox" id="blog_topmod_count" type="text" size="3" maxlength="255" name="novus-options[blog_topmod_count]" value="<?php echo $option['blog_topmod_count']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 50][module=op-blog_topmod_count]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_topmod_count" class="rthide">Post count for Popular Posts and Recent Posts.</div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Search:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_search"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_search]" id="blog_search" <?php if($option['blog_search'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_search" for="blog_search"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_search]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_search" class="rthide"><?php _re('Displays search box under posts.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Bottom Blogroll:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="blog_blogroll"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[blog_blogroll]" id="blog_blogroll" <?php if($option['blog_blogroll'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="blog_blogroll" for="blog_blogroll"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-blog_blogroll]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_blogroll" class="rthide"><?php _re('Displays the blogroll under the posts.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Blogroll Order:'); ?>
							</div>
							<div class="paramcheck">
								<label class="blog_blogroll_order">
									<select id="blog_blogroll_order" name="novus-options[blog_blogroll_order]">
      			   						<option value="ID" <?php if ($option['blog_blogroll_order'] == "ID") : ?>selected="selected"<?php endif; ?>>ID</option>    	
      			   						<option value="url" <?php if ($option['blog_blogroll_order'] == "url") : ?>selected="selected"<?php endif; ?>><?php _re('URL'); ?></option> 
      			   						<option value="name" <?php if ($option['blog_blogroll_order'] == "name") : ?>selected="selected"<?php endif; ?>><?php _re('Name'); ?></option> 
      			   						<option value="target" <?php if ($option['blog_blogroll_order'] == "target") : ?>selected="selected"<?php endif; ?>><?php _re('Target'); ?></option>
      			   						<option value="rating" <?php if ($option['blog_blogroll_order'] == "rating") : ?>selected="selected"<?php endif; ?>><?php _re('Rating'); ?></option>
      			   						<option value="updated" <?php if ($option['blog_blogroll_order'] == "updated") : ?>selected="selected"<?php endif; ?>><?php _re('Updated'); ?></option>
      			   						<option value="rss" <?php if ($option['blog_blogroll_order'] == "rss") : ?>selected="selected"<?php endif; ?>><?php _re('RSS'); ?></option>
      			   						<option value="lenght" <?php if ($option['blog_blogroll_order'] == "lenght") : ?>selected="selected"<?php endif; ?>><?php _re('Lenght'); ?></option>
      			   						<option value="rand" <?php if ($option['blog_blogroll_order'] == "rand") : ?>selected="selected"<?php endif; ?>><?php _re('Random'); ?></option>	    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 70][module=op-blog_blogroll_order]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_blogroll_order" class="rthide">Changes blogroll order in the bottom.</div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Blogroll Limit:'); ?>
							</div>
							<div class="paramcheck">
								<label class="blog_blogroll_limit">
									<input class="textbox" id="blog_blogroll_limit" type="text" size="3" maxlength="255" name="novus-options[blog_blogroll_limit]" value="<?php echo $option['blog_blogroll_limit']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 50][module=op-blog_blogroll_limit]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_blogroll_limit" class="rthide">Here you can limit the number of displayed links in blogroll, -1 displays all links.</div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Blogroll Category:'); ?>
							</div>
							<div class="paramcheck">
								<label class="blog_blogroll_category">
									<input class="textbox" id="blog_blogroll_category" type="text" size="3" maxlength="255" name="novus-options[blog_blogroll_category]" value="<?php echo $option['blog_blogroll_category']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 50][module=op-blog_blogroll_category]"><span class="help">Help</span></a>
							</div>
							<div id="op-blog_blogroll_category" class="rthide">Comma separated list of numeric Category IDs to be displayed. If none is specified, all Categories with bookmarks are shown.</div>
						</div>
					</td>
					<td class="secondcol">
					</td>
				</tr>
			</table>
			</div>
			
			<div class="inner-tabber">
			<a name="topmenu"></a>
			
			<span class="section-title"><?php _re('Top Menu'); ?></span><br /><br />
		
			<table class="options_table">
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Top Menu:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="top_menu"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[top_menu]" id="top_menu" <?php if($option['top_menu'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="top_menu" for="top_menu"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-top_menu]"><span class="help">Help</span></a>
							</div>
							<div id="op-top_menu" class="rthide"><?php _re('Enable / disable top menu.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Home Button:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="top_menu_home"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[top_menu_home]" id="top_menu_home" <?php if($option['top_menu_home'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="top_menu_home" for="top_menu_home"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-top_menu_home]"><span class="help">Help</span></a>
							</div>
							<div id="op-top_menu_home" class="rthide"><?php _re('Displays Home button in top menu.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Button Sorting:'); ?>
							</div>
							<div class="paramcheck">
								<label class="top_menu_sorting">
									<select id="top_menu_sorting" name="novus-options[top_menu_sorting]">
      			   						<option value="post_title" <?php if ($option['top_menu_sorting'] == "post_title") : ?>selected="selected"<?php endif; ?>><?php _re('Page Title'); ?></option>
      			     					<option value="menu_order" <?php if ($option['top_menu_sorting'] == "menu_order") : ?>selected="selected"<?php endif; ?>><?php _re('Page Order'); ?></option>
      			     					<option value="post_date" <?php if ($option['top_menu_sorting'] == "post_date") : ?>selected="selected"<?php endif; ?>><?php _re('Page Date'); ?></option>
      			     					<option value="post_modified" <?php if ($option['top_menu_sorting'] == "post_modified") : ?>selected="selected"<?php endif; ?>><?php _re('Page Modified'); ?></option>
      			     					<option value="ID" <?php if ($option['top_menu_sorting'] == "ID") : ?>selected="selected"<?php endif; ?>><?php _re('Page ID'); ?></option>
      			     					<option value="post_author" <?php if ($option['top_menu_sorting'] == "post_author") : ?>selected="selected"<?php endif; ?>><?php _re('Page Author'); ?></option>      			    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 70][module=op-top_menu_sorting]"><span class="help">Help</span></a>
							</div>
							<div id="op-top_menu_sorting" class="rthide">Choose by depending on what menu buttons should be displayed.</div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Exclude:'); ?>
							</div>
							<div class="paramcheck">
								<label class="top_menu_exclude">
									<input class="textbox" id="top_menu_exclude" type="text" size="12" maxlength="255" name="novus-options[top_menu_exclude]" value="<?php echo $option['top_menu_exclude']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 50][module=op-top_menu_exclude]"><span class="help">Help</span></a>
							</div>
							<div id="op-top_menu_exclude" class="rthide">Here you can exclude the pages from the Top Menu. Please type Page IDs separated by commas.</div>
						</div>
					</td>
				</tr>
			</table>
			</div>
			
			<div class="inner-tabber">
			<a name="footer"></a>
			
			<span class="section-title"><?php _re('Footer'); ?></span><br /><br />
		
			<table class="options_table">
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Footer Display:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="footer_enabled"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[footer_enabled]" id="footer_enabled" <?php if($option['footer_enabled'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="footer_enabled" for="footer_enabled"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-footer_enabled]"><span class="help">Help</span></a>
							</div>
							<div id="op-footer_enabled" class="rthide"><?php _re('Enable / disable footer display.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('RocketTheme Logo:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="footer_logo"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[footer_logo]" id="footer_logo" <?php if($option['footer_logo'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="footer_logo" for="footer_logo"></label><?php } ?>
								<a href="#" rel="rokbox[350 50][module=op-rocket_logo]"><span class="help">Help</span></a>
							</div>
							<div id="op-rocket_logo" class="rthide"><?php _re('Displays RocketTheme logo in the footer.'); ?></div>
						</div>
					</td>
				</tr>
			</table>
			</div>
			
			<div class="inner-tabber">
			<a name="dimensions"></a>
			
			<span class="section-title"><?php _re('Dimensions'); ?></span><br /><br />
		
			<table class="options_table">
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Site Width:'); ?>
							</div>
							<div class="paramcheck">
								<label class="site_width">
									<input class="textbox" id="site_width" type="text" size="3" maxlength="255" name="novus-options[site_width]" value="<?php echo $option['site_width']; ?>" />px
                   				</label>
                   				<a href="#" rel="rokbox[350 70][module=op-site_width]"><span class="help">Help</span></a>
							</div>
							<div id="op-site_width" class="rthide"><?php _re('Here you can change the site width.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Left Column Width:'); ?>
							</div>
							<div class="paramcheck">
								<label class="left_sidebar_w">
									<input class="textbox" id="left_sidebar_w" type="text" size="3" maxlength="255" name="novus-options[left_sidebar_w]" value="<?php echo $option['left_sidebar_w']; ?>" />%
                   				</label>
                   				<a href="#" rel="rokbox[350 70][module=op-sidebar_left_width]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_width" class="rthide"><?php _re('Here you can change width of the left sidebar.'); ?></div>
						</div>
					</td>
				</tr>
			</table>
			</div>
			
			<div class="inner-tabber">
			<a name="rokbox"></a>
			
			<span class="section-title">RokBox</span><br /><br />
		
			<table class="options_table">
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('RokBox:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="rokbox_enabled"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[rokbox_enabled]" id="rokbox_enabled" <?php if($option['rokbox_enabled'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="rokbox_enabled" for="rokbox_enabled"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-rokbox]"><span class="help">Help</span></a>
							</div>
							<div id="op-rokbox" class="rthide"><?php _re('RokBox is a mootools powered JavaScript slideshow that allows you to quickly and easily display multiple media formats including images, videos (video sharing services also) and music.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('RokBox Style:'); ?>
							</div>
							<div class="paramcheck">
								<label class="rokbox_style">
									<select id="rokbox_style" name="novus-options[rokbox_style]">
      			      					<option value="light" <?php if ($option['rokbox_style'] == "light") : ?>selected="selected"<?php endif; ?>><?php _re('Light'); ?></option>
      			    					<option value="dark" <?php if ($option['rokbox_style'] == "dark") : ?>selected="selected"<?php endif; ?>><?php _re('Dark'); ?></option>
      			    					<option value="mynxx" <?php if ($option['rokbox_style'] == "mynxx") : ?>selected="selected"<?php endif; ?>><?php _re('Mynxx'); ?></option>
                   					</select>
								</label>
								<a href="#" rel="rokbox[350 50][module=op-rokbox-style]"><span class="help">Help</span></a>
							</div>
							<div id="op-rokbox-style" class="rthide"><?php _re('Your media can be displayed using one of the three great styles for RokBox.'); ?></div>
						</div>
					</td>
				</tr>
			</table>
			</div>
										
		</div>
		<div class="clr"></div>
		
	</div>