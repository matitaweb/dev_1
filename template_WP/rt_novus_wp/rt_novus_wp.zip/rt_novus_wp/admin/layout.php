<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
?>
<?php

	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'layout.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

?>

	<?php $option = get_option('novus-options'); ?>	
	
	<div class="general-wrapper">

		<div class="tabbar">
		
			<div class="tab1 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#front"><?php _re('Front Page'); ?></a></div>
			</div>
			
			<div class="tab2 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#sub"><?php _re('Subpages'); ?></a></div>
			</div>
			
			<div class="tab3 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#leftside"><?php _re('Left Sidebar'); ?></a></div>
			</div>
			
			<div class="tab4 singletab">
				<div class="tabl"></div>
				<div class="tabr"><a href="#leftsidesub"><?php _re('Left Sidebar Subpage'); ?></a></div>
			</div>
	
		</div>
		<div class="clr"></div>
					
		<div class="main-general">
		
			<div class="inner-tabber">
			<a name="front"></a>
			
			<span class="section-title"><?php _re('Front Page'); ?></span><br /><br />
		
			<table class="options_table layout_chooser">
				<tr>
					<td class="bigcol">
						<div class="scx<?php if(rok_isIE(6)) { echo ' ie6margin'; } ?>">
							<input id="scx" type="radio" <?php if ($option['layout_front'] == "s-c-x") : ?>checked="checked"<?php endif; ?> value="s-c-x" name="novus-options[layout_front]"/>
							<label for="scx" class="layout-title"><?php if(rok_isIE(6)) { _re('Sidebar - Content - X'); } ?></label>
						</div>
						<div class="xcx<?php if(rok_isIE(6)) { echo ' ie6margin'; } ?>">
							<input id="xcx" type="radio" <?php if ($option['layout_front'] == "x-c-x") : ?>checked="checked"<?php endif; ?> value="x-c-x" name="novus-options[layout_front]"/>
							<label for="xcx" class="layout-title"><?php if(rok_isIE(6)) { _re('X - Content - X'); } ?></label>
						</div>
					</td>
				</tr>
			</table>
			</div>
			
			<div class="inner-tabber">
			<a name="sub"></a>
			
			<span class="section-title"><?php _re('Subpages'); ?></span><br /><br />
		
			<table class="options_table layout_chooser">
				<tr>
					<td class="bigcol">
						<div class="sub-scx<?php if(rok_isIE(6)) { echo ' ie6margin'; } ?>">
							<input id="sub-scx" type="radio" <?php if ($option['layout_subpage'] == "s-c-x") : ?>checked="checked"<?php endif; ?> value="s-c-x" name="novus-options[layout_subpage]"/>
							<label for="sub-scx" class="layout-title"><?php if(rok_isIE(6)) { _re('Sidebar - Content - X'); } ?></label>
						</div>
						<div class="sub-xcx<?php if(rok_isIE(6)) { echo ' ie6margin'; } ?>">
							<input id="sub-xcx" type="radio" <?php if ($option['layout_subpage'] == "x-c-x") : ?>checked="checked"<?php endif; ?> value="x-c-x" name="novus-options[layout_subpage]"/>
							<label for="sub-xcx" class="layout-title"><?php if(rok_isIE(6)) { _re('X - Content - X'); } ?></label>
						</div>
					</td>
				</tr>
			</table>
			</div>
			
			<div class="inner-tabber">
			<a name="leftside"></a>
			
			<span class="section-title"><?php _re('Left Sidebar:'); ?></span><br /><br />
		
			<table class="options_table">
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Sidebar File:'); ?>
							</div>
							<div class="paramcheck">
								<label class="left_front_side_file">
									<input class="textbox" id="left_front_side_file" type="text" size="16" maxlength="255" name="novus-options[left_front_side_file]" value="<?php echo $option['left_front_side_file']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 70][module=op-left_front_side_file]"><span class="help">Help</span></a>
							</div>
							<div id="op-left_front_side_file" class="rthide"><?php _re('Name of the file that holds all default sidebar content. File is located inside theme/includes directory.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Categories:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="sidebar_left_front_categories"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[sidebar_left_front_categories]" id="sidebar_left_front_categories" <?php if($option['sidebar_left_front_categories'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="sidebar_left_front_categories" for="sidebar_left_front_categories"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-sidebar_left_front_categories]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_categories" class="rthide"><?php _re('Displays categories in left subpage sidebar.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Empty Categories:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="sidebar_left_front_categories_empty"><?php } ?><input type="checkbox" value="1" class="checkbox" name="novus-options[sidebar_left_front_categories_empty]" id="sidebar_left_front_categories_empty" <?php if($option['sidebar_left_front_categories_empty'] == '1') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="sidebar_left_front_categories_empty" for="sidebar_left_front_categories_empty"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-sidebar_left_front_categories_empty]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_categories_empty" class="rthide"><?php _re('Display / hide empty categories in left subpage sidebar.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Categories Order:'); ?>
							</div>
							<div class="paramcheck stubborn">
								<label class="sidebar_left_front_categories_order">
									<select id="sidebar_left_front_categories_order" name="novus-options[sidebar_left_front_categories_order]">
      			   						<option value="ID" <?php if ($option['sidebar_left_front_categories_order'] == "ID") : ?>selected="selected"<?php endif; ?>>ID</option>    	
      			   						<option value="name" <?php if ($option['sidebar_left_front_categories_order'] == "name") : ?>selected="selected"<?php endif; ?>><?php _re('Name'); ?></option> 
      			   						<option value="slug" <?php if ($option['sidebar_left_front_categories_order'] == "slug") : ?>selected="selected"<?php endif; ?>><?php _re('Slug'); ?></option> 
      			   						<option value="count" <?php if ($option['sidebar_left_front_categories_order'] == "count") : ?>selected="selected"<?php endif; ?>><?php _re('Count'); ?></option>		    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 70][module=op-sidebar_left_front_categories_order]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_categories_order" class="rthide"><?php _re('You can change order of the categories.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Categories Exclude:'); ?>
							</div>
							<div class="paramcheck">
								<label class="sidebar_left_front_categories_exclude">
									<input class="textbox" id="sidebar_left_front_categories_exclude" type="text" size="10" maxlength="255" name="novus-options[sidebar_left_front_categories_exclude]" value="<?php echo $option['sidebar_left_front_categories_exclude']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 70][module=op-sidebar_left_front_categories_exclude]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_categories_exclude" class="rthide"><?php _re('ID of categories that you wish to exclude from the list in the sidebar. Please split categories with comma.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Archives:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="sidebar_left_front_archives"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[sidebar_left_front_archives]" id="sidebar_left_front_archives" <?php if($option['sidebar_left_front_archives'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="sidebar_left_front_archives" for="sidebar_left_front_archives"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-sidebar_left_front_archives]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_archives" class="rthide"><?php _re('Displays archives in left subpage sidebar.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Archives Type:'); ?>
							</div>
							<div class="paramcheck">
								<label class="sidebar_left_front_archives_type">
									<select id="sidebar_left_front_archives_type" name="novus-options[sidebar_left_front_archives_type]">
      			   						<option value="yearly" <?php if ($option['sidebar_left_front_archives_type'] == "yearly") : ?>selected="selected"<?php endif; ?>><?php _re('Yearly'); ?></option>    	
      			   						<option value="monthly" <?php if ($option['sidebar_left_front_archives_type'] == "monthly") : ?>selected="selected"<?php endif; ?>><?php _re('Monthly'); ?></option> 
      			   						<option value="daily" <?php if ($option['sidebar_left_front_archives_type'] == "daily") : ?>selected="selected"<?php endif; ?>><?php _re('Daily'); ?></option> 
      			   						<option value="weekly" <?php if ($option['sidebar_left_front_archives_type'] == "weekly") : ?>selected="selected"<?php endif; ?>><?php _re('Weekly'); ?></option>
      			   						<option value="postbypost" <?php if ($option['sidebar_left_front_archives_type'] == "postbypost") : ?>selected="selected"<?php endif; ?>><?php _re('Post By Post'); ?></option>		    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 70][module=op-sidebar_left_front_archives_type]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_archives_type" class="rthide"><?php _re('Type of displayed archives.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Archives Limit:'); ?>
							</div>
							<div class="paramcheck">
								<label class="sidebar_left_front_archives_limit">
									<input class="textbox" id="sidebar_left_front_archives_limit" type="text" size="3" maxlength="255" name="novus-options[sidebar_left_front_archives_limit]" value="<?php echo $option['sidebar_left_front_archives_limit']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 50][module=op-sidebar_left_front_archives_limit]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_archives_limit" class="rthide"><?php _re('Here you can limit the number of displayed archives.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Tags:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="sidebar_left_front_tags"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[sidebar_left_front_tags]" id="sidebar_left_front_tags" <?php if($option['sidebar_left_front_tags'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="sidebar_left_front_tags" for="sidebar_left_front_tags"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-sidebar_left_front_tags]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_tags" class="rthide"><?php _re('Displays tags in left subpage sidebar.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Tags Order:'); ?>
							</div>
							<div class="paramcheck">
								<label class="sidebar_left_front_tags_order">
									<select id="sidebar_left_front_tags_order" name="novus-options[sidebar_left_front_tags_order]">
      			   						<option value="name" <?php if ($option['sidebar_left_front_tags_order'] == "name") : ?>selected="selected"<?php endif; ?>><?php _re('Name'); ?></option>    	
      			   						<option value="count" <?php if ($option['sidebar_left_front_tags_order'] == "count") : ?>selected="selected"<?php endif; ?>><?php _re('Count'); ?></option> 	    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 70][module=op-sidebar_left_front_tags_order]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_front_tags_order" class="rthide"><?php _re('Order of tags.'); ?></div>
						</div>
					</td>
				</tr>
			</table>
			</div>
			
			<div class="inner-tabber">
			<a name="leftsidesub"></a>
			
			<span class="section-title"><?php _re('Left Subpage Sidebar:'); ?></span><br /><br />
		
			<table class="options_table">
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Sidebar File:'); ?>
							</div>
							<div class="paramcheck">
								<label class="left_sub_side_file">
									<input class="textbox" id="left_sub_side_file" type="text" size="16" maxlength="255" name="novus-options[left_sub_side_file]" value="<?php echo $option['left_sub_side_file']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 70][module=op-left_sub_side_file]"><span class="help">Help</span></a>
							</div>
							<div id="op-left_sub_side_file" class="rthide"><?php _re('Name of the file that holds all default sidebar content. File is located inside theme/includes directory.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Categories:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="sidebar_left_sub_categories"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[sidebar_left_sub_categories]" id="sidebar_left_sub_categories" <?php if($option['sidebar_left_sub_categories'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="sidebar_left_sub_categories" for="sidebar_left_sub_categories"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-sidebar_left_sub_categories]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_categories" class="rthide"><?php _re('Displays categories in left subpage sidebar.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Empty Categories:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="sidebar_left_sub_categories_empty"><?php } ?><input type="checkbox" value="1" class="checkbox" name="novus-options[sidebar_left_sub_categories_empty]" id="sidebar_left_sub_categories_empty" <?php if($option['sidebar_left_sub_categories_empty'] == '1') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="sidebar_left_sub_categories_empty" for="sidebar_left_sub_categories_empty"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-sidebar_left_sub_categories_empty]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_categories_empty" class="rthide"><?php _re('Display / hide empty categories in left subpage sidebar.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Categories Order:'); ?>
							</div>
							<div class="paramcheck stubborn">
								<label class="sidebar_left_sub_categories_order">
									<select id="sidebar_left_sub_categories_order" name="novus-options[sidebar_left_sub_categories_order]">
      			   						<option value="ID" <?php if ($option['sidebar_left_sub_categories_order'] == "ID") : ?>selected="selected"<?php endif; ?>>ID</option>    	
      			   						<option value="name" <?php if ($option['sidebar_left_sub_categories_order'] == "name") : ?>selected="selected"<?php endif; ?>><?php _re('Name'); ?></option> 
      			   						<option value="slug" <?php if ($option['sidebar_left_sub_categories_order'] == "slug") : ?>selected="selected"<?php endif; ?>><?php _re('Slug'); ?></option> 
      			   						<option value="count" <?php if ($option['sidebar_left_sub_categories_order'] == "count") : ?>selected="selected"<?php endif; ?>><?php _re('Count'); ?></option>		    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 70][module=op-sidebar_left_sub_categories_order]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_categories_order" class="rthide"><?php _re('You can change order of the categories.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Categories Exclude:'); ?>
							</div>
							<div class="paramcheck">
								<label class="sidebar_left_sub_categories_exclude">
									<input class="textbox" id="sidebar_left_sub_categories_exclude" type="text" size="10" maxlength="255" name="novus-options[sidebar_left_sub_categories_exclude]" value="<?php echo $option['sidebar_left_sub_categories_exclude']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 70][module=op-sidebar_left_sub_categories_exclude]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_categories_exclude" class="rthide"><?php _re('ID of categories that you wish to exclude from the list in the sidebar. Please split categories with comma.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Archives:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="sidebar_left_sub_archives"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[sidebar_left_sub_archives]" id="sidebar_left_sub_archives" <?php if($option['sidebar_left_sub_archives'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="sidebar_left_sub_archives" for="sidebar_left_sub_archives"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-sidebar_left_sub_archives]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_archives" class="rthide"><?php _re('Displays archives in left subpage sidebar.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Archives Type:'); ?>
							</div>
							<div class="paramcheck">
								<label class="sidebar_left_sub_archives_type">
									<select id="sidebar_left_sub_archives_type" name="novus-options[sidebar_left_sub_archives_type]">
      			   						<option value="yearly" <?php if ($option['sidebar_left_sub_archives_type'] == "yearly") : ?>selected="selected"<?php endif; ?>><?php _re('Yearly'); ?></option>    	
      			   						<option value="monthly" <?php if ($option['sidebar_left_sub_archives_type'] == "monthly") : ?>selected="selected"<?php endif; ?>><?php _re('Monthly'); ?></option> 
      			   						<option value="daily" <?php if ($option['sidebar_left_sub_archives_type'] == "daily") : ?>selected="selected"<?php endif; ?>><?php _re('Daily'); ?></option> 
      			   						<option value="weekly" <?php if ($option['sidebar_left_sub_archives_type'] == "weekly") : ?>selected="selected"<?php endif; ?>><?php _re('Weekly'); ?></option>
      			   						<option value="postbypost" <?php if ($option['sidebar_left_sub_archives_type'] == "postbypost") : ?>selected="selected"<?php endif; ?>><?php _re('Post By Post'); ?></option>		    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 70][module=op-sidebar_left_sub_archives_type]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_archives_type" class="rthide"><?php _re('Type of displayed archives.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Archives Limit:'); ?>
							</div>
							<div class="paramcheck">
								<label class="sidebar_left_sub_archives_limit">
									<input class="textbox" id="sidebar_left_sub_archives_limit" type="text" size="3" maxlength="255" name="novus-options[sidebar_left_sub_archives_limit]" value="<?php echo $option['sidebar_left_sub_archives_limit']; ?>" />
                   				</label>
                   				<a href="#" rel="rokbox[350 50][module=op-sidebar_left_sub_archives_limit]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_archives_limit" class="rthide"><?php _re('Here you can limit the number of displayed archives.'); ?></div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="firstcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Tags:'); ?>
							</div>
							<div class="paramcheck onlycheck">
								<?php if(rok_isIE()) { ?><label class="sidebar_left_sub_tags"><?php } ?><input type="checkbox" value="true" class="checkbox" name="novus-options[sidebar_left_sub_tags]" id="sidebar_left_sub_tags" <?php if($option['sidebar_left_sub_tags'] == 'true') { ?>checked="checked"<?php } ?> /><?php if(rok_isIE()) { ?></label><?php } ?>
								<?php if(!rok_isIE()) { ?><label class="sidebar_left_sub_tags" for="sidebar_left_sub_tags"></label><?php } ?>
								<a href="#" rel="rokbox[350 70][module=op-sidebar_left_sub_tags]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_tags" class="rthide"><?php _re('Displays tags in left subpage sidebar.'); ?></div>
						</div>
					</td>
					<td class="secondcol">
						<div class="paramfield">
							<div class="paramtext">
								<?php _re('Tags Order:'); ?>
							</div>
							<div class="paramcheck">
								<label class="sidebar_left_sub_tags_order">
									<select id="sidebar_left_sub_tags_order" name="novus-options[sidebar_left_sub_tags_order]">
      			   						<option value="name" <?php if ($option['sidebar_left_sub_tags_order'] == "name") : ?>selected="selected"<?php endif; ?>><?php _re('Name'); ?></option>    	
      			   						<option value="count" <?php if ($option['sidebar_left_sub_tags_order'] == "count") : ?>selected="selected"<?php endif; ?>><?php _re('Count'); ?></option> 	    				
      			     				</select>
      			     			</label>
      			     			<a href="#" rel="rokbox[350 70][module=op-sidebar_left_sub_tags_order]"><span class="help">Help</span></a>
							</div>
							<div id="op-sidebar_left_sub_tags_order" class="rthide"><?php _re('Order of tags.'); ?></div>
						</div>
					</td>
				</tr>
			</table>
			</div>
										
		</div>
		<div class="clr"></div>
		
	</div>