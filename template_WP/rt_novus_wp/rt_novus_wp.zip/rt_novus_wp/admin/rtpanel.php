<?php
/**
 * @version   Novus WordPress Theme
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
?>
<?php

	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'rtpanel.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

?>

	<?php if(isset($_GET['updated']) == 'true') { ?><div id="message" class="updated fade"><p>Theme settings saved.</p></div><?php } ?>
	
	<?php $option = get_option('novus-options'); ?>

	<div id="rtpanel">
		
		<script type="text/javascript">
			RokTabsOptions.duration.push(600);
			RokTabsOptions.transition.push(Fx.Transitions.Quad.easeInOut);
			RokTabsOptions.auto.push(0);
			RokTabsOptions.delay.push(2000);
			RokTabsOptions.type.push('scrolling');
			RokTabsOptions.linksMargins.push(0);
		</script>
	
		<div class="tabs-top">
			<div class="roktabs-wrapper" style="width: 770px;">
				<div class="roktabs base">
				
					<form method="post" action="options.php">
    				<?php settings_fields('theme-options-array'); ?>
				
					<div id="top">
						<div id="rt-top-l" class="png"></div>
						<div id="rt-top-m" class="png">
							<div class='roktabs-links'>
								<ul class='roktabs-top'>
									<li class="first active"><a href="#" title="GENERAL" class="roktips topgeneral"><span class="rthide">General</span></a></li>
									<li><a href="#" title="STYLE" class="roktips topstyle"><span class="rthide">Style</span></a></li>
									<li class="last"><a href="#" title="LAYOUT" class="roktips toplayout"><span class="rthide">Layout</span></a></li>
								</ul>
							</div>
							<ul class="additional-button">
								<li><a href="http://www.rockettheme.com/forum/index.php?f=330&amp;rb_v=viewforum" target="_blank" title="FORUMS" class="roktips topforums"><span class="rthide">Forums</span></a></li>
							</ul>
							<div class="submit-wrapper png"><input type="submit" class="submit-button" value="<?php _e('Save Changes'); ?>" /></div>
						</div>
						<div id="rt-top-r" class="png"></div>
					</div>
					<div class="clr"></div>
		
					<div id="maincontent">
						
						<div class="roktabs-container-inner">
							<div class="roktabs-container-wrapper">
		
								<div class='roktabs-tab1 tabcont'>
									<div class='wrapper'>
										
										<?php include('general.php'); ?>
					
									</div>
								</div>
						
								<div class='roktabs-tab2 tabcont'>
									<div class='wrapper'>
					
										<?php include('style.php'); ?>
					
									</div>
								</div>
							
								<div class='roktabs-tab3 tabcont'>
									<div class='wrapper'>
		
										<?php include('layout.php'); ?>
					
									</div>
								</div>
								
								<div class='roktabs-tab4 tabcont'>
									<div class='wrapper'>
		
										<?php include('sections.php'); ?>
					
									</div>
								</div>
					
							</div>
						</div>				
					</div>
					<div class="clr"></div>
		
					<div id="bottom">
						<div id="rt-bot-l" class="png"></div>
						<div id="rt-bot-m" class="png">
							<div id="rocket" class="png"></div>
							<div class="submit-wrapper png"><input type="submit" class="submit-button" value="<?php _e('Save Changes'); ?>" /></div>
						</div>
						<div id="rt-bot-r" class="png"></div>
					</div>
					<div class="clr"></div>
					
					</form>
								
				</div>
			</div>
		</div>
	</div>