<?php
/**
 * @version   1.12 February 15, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

defined('GANTRY_VERSION') or die;

gantry_import('core.config.gantryformgroup');


class GantryFormGroupChain extends GantryFormGroup
{
    protected $type = 'chain';
    protected $baseetype = 'group';

    public function getInput(){
        $buffer = '';

		$buffer .= "<div class='wrapper'>\n";
        foreach ($this->fields as $field) {
            $itemName = $this->fieldname."-".$field->fieldname;
            
            $buffer .= '<div class="chain '.$itemName.' chain-'.strtolower($field->type).'">'."\n";
            $buffer .= '<span class="chain-label">'._r($field->label).'</span>'."\n";
            $buffer .= $field->getInput();
            $buffer .= "</div>"."\n";

        }
		$buffer .= "</div>"."\n";

        return $buffer;
    }
}