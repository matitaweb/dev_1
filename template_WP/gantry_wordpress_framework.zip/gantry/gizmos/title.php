<?php
/**
 * @version   1.12 February 15, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */

defined('GANTRY_VERSION') or die();

gantry_import('core.gantrygizmo');

/**
 * @package     gantry
 * @subpackage  features
 */
class GantryGizmoTitle extends GantryGizmo {

    var $_name = 'title';

    function isEnabled(){
        return true;
    }


    function query_parsed_init() {
        global $gantry, $post, $s, $wp_query;
        
        $title = trim($gantry->get('title-format'));
        
        if($title != '') {
        
        	// Single posts
	        if (is_single()) {
	        
	        	$categories = get_the_category();
	        	if (count($categories) > 0) {
					$category = $categories[0]->cat_name;
				}
				
				$author = get_userdata($post->post_author);
	        
	        	$token = array(
        		    '%blog_title%',
				    '%blog_description%',
				    '%post_title%',
				    '%category%',
				    '%post_author_login%',
				    '%post_author_nicename%',
				    '%post_author_firstname%',
				    '%post_author_lastname%'
	        	);
	        	
	        	$replace = array(
	        		get_bloginfo('name'),
	        		get_bloginfo('description'),
	        		get_the_title(),
	        		$category,
					$author->user_login,
					$author->user_nicename,
					$author->first_name,
					$author->last_name
	        	);
	        	
	        	$title = str_replace($token, $replace, $title);
	
	            // The home page or, if using a static front page, the blog posts page.
	        } elseif (is_home() || is_front_page()) {
	        
	        	$token = array(
        		    '%blog_title%',
				    '%blog_description%'
	        	);
	        	
	        	$replace = array(
	        		get_bloginfo('name'),
	        		get_bloginfo('description')
	        	);
	        	
	        	$title = str_replace($token, $replace, $title);
	
	            // WordPress Pages
	        } elseif (is_page()) {
	        
	        	$author = get_userdata($post->post_author);
	        
	        	$token = array(
        		    '%blog_title%',
				    '%blog_description%',
				    '%page_title%',
				    '%page_author_login%',
				    '%page_author_nicename%',
				    '%page_author_firstname%',
				    '%page_author_lastname%'
	        	);
	        	
	        	$replace = array(
	        		get_bloginfo('name'),
	        		get_bloginfo('description'),
	        		get_the_title(),
					$author->user_login,
					$author->user_nicename,
					$author->first_name,
					$author->last_name
	        	);
	        	
	        	$title = str_replace($token, $replace, $title);	        	
	        	
	        // Category Pages
	        } elseif (is_category()) {
	        
	        	$token = array(
        		    '%blog_title%',
				    '%blog_description%',
				    '%category_title%',
				    '%category_description%'
	        	);
	        	
	        	$replace = array(
	        		get_bloginfo('name'),
	        		get_bloginfo('description'),
	        		single_cat_title('', false),
					category_description()
	        	);
	        	
	        	$title = str_replace($token, $replace, $title);	
	        	
	       	// Archive Pages
	        } elseif (is_day() || is_month() || is_year() || is_author()) {
	        
	        	$token = array(
        		    '%blog_title%',
				    '%blog_description%',
				    '%date%'
	        	);
	        	
	        	$replace = array(
	        		get_bloginfo('name'),
	        		get_bloginfo('description'),
					wp_title('', false)
	        	);
	        	
	        	$title = str_replace($token, $replace, $title);	 
	        	
	       	// Tags Pages
	        } elseif (is_tag()) {
	        
	        	$token = array(
        		    '%blog_title%',
				    '%blog_description%',
				    '%tag%'
	        	);
	        	
	        	$replace = array(
	        		get_bloginfo('name'),
	        		get_bloginfo('description'),
					$wp_query->query_vars['tag']
	        	);
	        	
	        	$title = str_replace($token, $replace, $title);      	
	
	            // Search results
	        } elseif (is_search()) {
	        
	        	$token = array(
        		    '%blog_title%',
				    '%blog_description%',
				    '%search%'
	        	);
	        	
	        	$replace = array(
	        		get_bloginfo('name'),
	        		get_bloginfo('description'),
	        		$s
	        	);
	        	
	        	$title = str_replace($token, $replace, $title); 	
	
	            // 404 (Not Found)
	        } elseif (is_404()) {
	        
	        	$token = array(
        		    '%blog_title%',
        		    '%blog_description%',
				    '%request_url%',
					'%404_title%'
	        	);
	        	
	        	$replace = array(
	        		get_bloginfo('name'),
	        		get_bloginfo('description'),
	        		$_SERVER['REQUEST_URI'],
	        		wp_title('', false)
	        	);
	        	
	        	$title = str_replace($token, $replace, $title); 	
	        	
	            // Otherwise:
	        } else {
	        
	        	$title = wp_title('', false) . ' | ' . get_bloginfo('name');
	        
	        }
	        
	        $gantry->pageTitle = trim($title);

        
        } else {

	        // Single posts
	        if (is_single()) {
	            $gantry->pageTitle = single_post_title('', false) . ' | ' . get_bloginfo('name');
	
	            // The home page or, if using a static front page, the blog posts page.
	        } elseif (is_home() || is_front_page()) {
	            $gantry->pageTitle = get_bloginfo('name');
	            if (get_bloginfo('description'))
	                $gantry->pageTitle .= ' | ' . get_bloginfo('description');
	
	            // WordPress Pages
	        } elseif (is_page()) {
	            $gantry->pageTitle = single_post_title('', false) . ' | ' . get_bloginfo('name');
	
	            // Search results
	        } elseif (is_search()) {
	            $gantry->pageTitle = _g('Search results for ') . '"' . get_search_query() . '"' . ' | ' . get_bloginfo('name');
	
	            // 404 (Not Found)
	        } elseif (is_404()) {
	            $gantry->pageTitle = _g('Not Found') . ' | ' . get_bloginfo('name');
	
	            // Otherwise:
	        } else {
	            $gantry->pageTitle = wp_title('', false) . ' | ' . get_bloginfo('name');
	        }
        
        }

    }
}