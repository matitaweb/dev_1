<?php
/**
 * Gantry For Wordpress
 * 
 * @version   1.12 February 15, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
die();
?>

1. Copyright and disclaimer
----------------


2. Changelog
------------
This is a non-exhaustive changelog for Gantry, inclusive of any alpha, beta, release candidate and final versions.

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

------- 1.11 Release [] ------
^ Change to help prevent conflict with template modifiers like wptouch

------- 1.10 Release [] -------
^ Added input and tokens to the title gizmo
+ Added accessibility css code
# Fixed bug with currentUrl not being set right
^ Moved base init to template redirect
^ Added user css code
^ Added Category field to the Recent Posts widget

------- 1.9 Release [] -------
# Added better Cookie Path handling
# Fixed widget override selection bug!  Yee Ha!

------- 1.8 Release [] -------
# Fixed Menu Items Assignements in Overrides
# Fixed Preset Saver in the backend
+ Added RokStyle gizmo
+ Added AutoParagraph gizmo
^ Updated MooTools to 1.3

------- 1.7 Release [] -------
# Added RTL css file support from gantry
+ Added Page Suffix gizmo
^ Modified the default comment styling
^ Logo points now to the Site URL not WP URL
^ Breadcrumbs 'Home' button points now to the Site URL not WP URL
+ Added default styling and home image for the breadcrumbs
^ Moved the Home button in breadcrumbs to be widget powered
^ Fixed pagination position in RTL mode
^ Swapped left padding to right one for lists in RTL
+ Added get_header, get_footer, and get_sidebar actions to help plugin compatibility
# Fixed Push pull for sidebars in RTL
+ Added Overlay field type
^ Added spans to links in certain widgets
^ Added default styling for Recent Comments widget
^ Breadcrumbs pathway will only appear on the single post or custom page

------- 1.6 Release [] -------
# Fixed swapping widget IDs in overrides

------- 1.5 Release [] -------
# Added check for empty widget postions in render
^ Gantry Logo widget 'Per Style' setting is no longer hidden
^ Changed some JS binds to follow the new ES5 specs
# Fixed Colorchooser and Gradient fields
+ Added cache removal to default widget and override widget ajax actions
^ Gantry Pages widget is adding extra 'active' class for current page
^ Gantry Categories widget is adding extra 'active' class for current category
^ Changed width and padding for the MU Register form
# Fix for cache clear issues
+ Made widget instance overrides available to ajax calls

------- 1.4 Release [] -------
^ Added displayFooter function and supporting renders for themes.
^ Add mootools script in jstools gizmo
# Fix for calling wp_head on the admin side.

------- 1.3 Release [] -------
# Fix for layouts not reversing in RTL mode
# Fix for Duplicating and missing CSS files

------- 1.2 Release [] -------
+ Added Minefield to the list of Browsers
+ Add support for Signup page to template page overrides
^ Force Widget Accessability Mode off for Gantry Themes
# Fixed addStyle to better handle -override files and get propper css file overrides from template
^ Moved cache to be WP Transients based.
+ Added base level diagnostics


------- 1.1 Release [17-Aug-2010] -------
# Fixed support for non WP_Widget based classes.

------- 1.0 Release [15-Aug-2010] -------
! Changelog Creation