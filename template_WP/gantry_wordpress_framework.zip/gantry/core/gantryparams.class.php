<?php
/**
 * @version   1.12 February 15, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
defined('GANTRY_VERSION') or die();

/**
 * Base class for Gantry Parameter processor classes
 * @package   gantry
 * @subpackage core
 */
class GantryParams  {
    function store(){

    }
    function clean(){

    }
    function populate(){

    }
}