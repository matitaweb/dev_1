<?php
/**
 * @version   1.12 February 15, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

gantry_import('core.rules.gantryoverridefact');

class GantryFactTemplatePage extends GantryOverrideFact {
    function matchesCallPageType($query){
        $ret = false;

        $check = "is_".$this->type;
        switch($this->type){
            case 'wp-signup':
                if (basename($_SERVER['SCRIPT_NAME']) == 'wp-signup.php' && $query->is_home == true ){
                    $ret = true;
                }
                break;
            case 'home':
                if ($query->is_home == true && basename($_SERVER['SCRIPT_NAME']) != 'wp-signup.php'){
                    $ret = true;
                }
                break;
            default:
                $ret = $query->$check;
        }
        return $ret;
    }
}