<?php
require_once(sys_functions."/custom_post/portfolio.php");
require_once(sys_functions."/custom_post/slider.php");
require_once(sys_functions."/meta/post.php");
require_once(sys_functions."/meta/page.php");
require_once(sys_functions."/meta/portfolio.php");
require_once(sys_functions."/meta/slider.php");
?>