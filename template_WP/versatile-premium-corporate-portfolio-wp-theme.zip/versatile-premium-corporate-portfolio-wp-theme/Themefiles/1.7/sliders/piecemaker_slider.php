<?php require(sys_includes."/var.php"); ?>
<?php echo do_shortcode(stripslashes(get_option("piecemaker_id"))); ?>