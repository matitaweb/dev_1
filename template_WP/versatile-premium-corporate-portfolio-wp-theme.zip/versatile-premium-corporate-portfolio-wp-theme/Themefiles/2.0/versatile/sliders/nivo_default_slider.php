<?php require(sys_includes."/var.php"); 
?>
<div class="inner">
<!-- Start: Slider -->
<div id="slider">
	<a href="#"><img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php bloginfo( 'template_directory' ); ?>/images/slider_image.jpg&amp;w=600&amp;h=300&amp;zc=1" alt="" title="TITLE GOES HERE" /></a>
	<a href="#"><img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php bloginfo( 'template_directory' ); ?>/images/slider_image2.jpg&amp;w=600&amp;h=300&amp;zc=1" alt="" title="TITLE GOES HERE" /></a>
	<a href="#"><img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php bloginfo( 'template_directory' ); ?>/images/slider_image3.jpg&amp;w=600&amp;h=300&amp;zc=1" alt="" title="TITLE GOES HERE" /></a>
	<a href="#"><img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php bloginfo( 'template_directory' ); ?>/images/slider_image4.jpg&amp;w=600&amp;h=300&amp;zc=1" alt="" title="TITLE GOES HERE" /></a>
</div>
<div class="header_highlight">
  <h1><?php _e('Super Flexible Wordpress Theme','versatile_front');?></h1>
  <h4><?php _e('The ultimate all-in-one template. With over 40 unique style variations to choose from your website.','versatile_front');?></h4>
</div>
</div>